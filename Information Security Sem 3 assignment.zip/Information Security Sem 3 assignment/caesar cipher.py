def caesar_encrypt(plaintext, shift):
    ciphertext = ''
    for char in plaintext:
        if char.isalpha():
            # Determine whether it's uppercase or lowercase
            start = ord('A') if char.isupper() else ord('a')
            # Apply the shift and wrap around if needed
            shifted = (ord(char) - start + shift) % 26 + start
            ciphertext += chr(shifted)
        else:
            ciphertext += char
    return ciphertext

def caesar_decrypt(ciphertext, shift):
    return caesar_encrypt(ciphertext, -shift)


plaintext = "Hello, MCA SEM-3!"
shift = 3
encrypted_text = caesar_encrypt(plaintext, shift)
decrypted_text = caesar_decrypt(encrypted_text, shift)

print("Plaintext:", plaintext)
print("Encrypted text:", encrypted_text)
print("Decrypted text:", decrypted_text)

