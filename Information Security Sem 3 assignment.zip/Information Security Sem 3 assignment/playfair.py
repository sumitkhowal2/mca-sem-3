def generate_key_table(key):
    key = key.upper().replace("J", "I")
    key_set = set(key)
    alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"
    key_table = ""

    for char in key_set:
        if char in alphabet:
            alphabet = alphabet.replace(char, "")

    key_table = key + alphabet
    return key_table

def prepare_text(text):
    text = text.upper().replace("J", "I")
    text = [text[i:i+2] for i in range(0, len(text), 2)]
    for i in range(len(text)):
        if len(text[i]) == 1:
            text[i] += 'X'
    return text

def encrypt(plaintext, key):
    key_table = generate_key_table(key)
    plaintext = prepare_text(plaintext)
    ciphertext = ""

    for pair in plaintext:
        row1, col1 = divmod(key_table.index(pair[0]), 5)
        row2, col2 = divmod(key_table.index(pair[1]), 5)

        if row1 == row2:
            ciphertext += key_table[row1 * 5 + (col1 + 1) % 5] + key_table[row2 * 5 + (col2 + 1) % 5]
        elif col1 == col2:
            ciphertext += key_table[((row1 + 1) % 5) * 5 + col1] + key_table[((row2 + 1) % 5) * 5 + col2]
        else:
            ciphertext += key_table[row1 * 5 + col2] + key_table[row2 * 5 + col1]

    return ciphertext

def decrypt(ciphertext, key):
    key_table = generate_key_table(key)
    plaintext = ""

    for pair in prepare_text(ciphertext):
        row1, col1 = divmod(key_table.index(pair[0]), 5)
        row2, col2 = divmod(key_table.index(pair[1]), 5)

        if row1 == row2:
            plaintext += key_table[row1 * 5 + (col1 - 1) % 5] + key_table[row2 * 5 + (col2 - 1) % 5]
        elif col1 == col2:
            plaintext += key_table[((row1 - 1) % 5) * 5 + col1] + key_table[((row2 - 1) % 5) * 5 + col2]
        else:
            plaintext += key_table[row1 * 5 + col2] + key_table[row2 * 5 + col1]

    return plaintext

def main():
    key = input("Enter the key: ")
    plaintext = input("Enter the plaintext: ")

    encrypted_text = encrypt(plaintext, key)
    print("Encrypted text:", encrypted_text)

    decrypted_text = decrypt(encrypted_text, key)
    print("Decrypted text:", decrypted_text)

if __name__ == "__main__":
    main()

