import numpy as np

class HillCipher:
    def __init__(self, key):
        self.key = key

    def encrypt(self, plaintext):
        plaintext = plaintext.upper().replace(' ', '')
        n = len(self.key)
        plaintext_blocks = [plaintext[i:i+n] for i in range(0, len(plaintext), n)]
        ciphertext = ''

        for block in plaintext_blocks:
            if len(block) < n:
                block += 'X' * (n - len(block))

            block_nums = [ord(char) - 65 for char in block]
            block_matrix = np.array(block_nums).reshape(n, -1)
            encrypted_block_matrix = np.dot(self.key, block_matrix) % 26
            encrypted_block = ''.join([chr(num + 65) for num in encrypted_block_matrix.flatten()])
            ciphertext += encrypted_block

        return ciphertext

    def decrypt(self, ciphertext):
        n = len(self.key)
        key_inv = self.modular_inverse(self.key, 26)
        decrypted_text = ''

        for i in range(0, len(ciphertext), n):
            block = ciphertext[i:i+n]
            block_nums = [ord(char) - 65 for char in block]
            block_matrix = np.array(block_nums).reshape(n, -1)
            decrypted_block_matrix = np.dot(key_inv, block_matrix) % 26
            decrypted_block = ''.join([chr(num + 65) for num in decrypted_block_matrix.flatten()])
            decrypted_text += decrypted_block

        return decrypted_text

    def modular_inverse(self, matrix, modulus):
        det = int(np.round(np.linalg.det(matrix)))
        det_inv = pow(det, -1, modulus)
        matrix_inv = np.round(det_inv * np.linalg.inv(matrix) * det) % modulus
        return matrix_inv.astype(int)

# Example usage:
key = np.array([[3, 2], [5, 7]])  # Example key matrix
cipher = HillCipher(key)

plaintext = "HELLO"
encrypted_text = cipher.encrypt(plaintext)
print("Encrypted:", encrypted_text)

decrypted_text = cipher.decrypt(encrypted_text)
print("Decrypted:", decrypted_text)

