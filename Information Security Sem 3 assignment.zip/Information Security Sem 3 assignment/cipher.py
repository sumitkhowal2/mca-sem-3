def encrypt(text, shift):
    encrypted_text = ''
    for char in text:
        # Check if character is an uppercase letter
        if char.isupper():
            encrypted_text += chr((ord(char) + shift - 65) % 26 + 65)
        # Check if character is a lowercase letter
        elif char.islower():
            encrypted_text += chr((ord(char) + shift - 97) % 26 + 97)
        else:
            # If the character is not a letter, keep it unchanged
            encrypted_text += char
    return encrypted_text


def decrypt(encrypted_text, shift):
    decrypted_text = ''
    for char in encrypted_text:
        if char.isupper():
            decrypted_text += chr((ord(char) - shift - 65) % 26 + 65)
        elif char.islower():
            decrypted_text += chr((ord(char) - shift - 97) % 26 + 97)
        else:
            decrypted_text += char
    return decrypted_text


def main():
    text = input("Enter the text to encrypt: ")
    shift = int(input("Enter the shift value (integer): "))

    encrypted_text = encrypt(text, shift)
    print("Encrypted text:", encrypted_text)

    decrypted_text = decrypt(encrypted_text, shift)
    print("Decrypted text:", decrypted_text)


if __name__ == "__main__":
    main()

