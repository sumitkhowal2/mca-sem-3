class VigenereCipher:
    def __init__(self, key):
        self.key = key.upper()

    def encrypt(self, plaintext):
        plaintext = plaintext.upper()
        ciphertext = ''
        key_index = 0

        for char in plaintext:
            if char.isalpha():
                shift = ord(self.key[key_index]) - 65
                encrypted_char = chr(((ord(char) - 65 + shift) % 26) + 65)
                ciphertext += encrypted_char
                key_index = (key_index + 1) % len(self.key)
            else:
                ciphertext += char

        return ciphertext

    def decrypt(self, ciphertext):
        ciphertext = ciphertext.upper()
        plaintext = ''
        key_index = 0

        for char in ciphertext:
            if char.isalpha():
                shift = ord(self.key[key_index]) - 65
                decrypted_char = chr(((ord(char) - 65 - shift + 26) % 26) + 65)
                plaintext += decrypted_char
                key_index = (key_index + 1) % len(self.key)
            else:
                plaintext += char

        return plaintext

# Example usage:
key = "KEY"
cipher = VigenereCipher(key)

plaintext = "HELLO"
encrypted_text = cipher.encrypt(plaintext)
print("Encrypted:", encrypted_text)

decrypted_text = cipher.decrypt(encrypted_text)
print("Decrypted:", decrypted_text)

