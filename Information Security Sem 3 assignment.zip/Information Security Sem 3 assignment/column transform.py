def column_transposition_encrypt(plaintext, key):
    num_cols = len(key)
    num_rows = -(-len(plaintext) // num_cols)
    matrix = [[''] * num_cols for _ in range(num_rows)]

    for i, char in enumerate(plaintext):
        matrix[i // num_cols][i % num_cols] = char

    ciphertext = ''
    for k in sorted(key):
        col_index = key.index(k)
        for row in matrix:
            if col_index < len(row):
                ciphertext += row[col_index]

    return ciphertext


def column_transposition_decrypt(ciphertext, key):
    num_cols = len(key)
    num_rows = -(-len(ciphertext) // num_cols)
    num_blanks = num_rows * num_cols - len(ciphertext)
    matrix = [[''] * num_cols for _ in range(num_rows)]

    index = 0
    for k in sorted(key):
        col_index = key.index(k)
        blanks = num_blanks if col_index >= num_cols - num_blanks else 0
        for i in range(num_rows - blanks):
            matrix[i][col_index] = ciphertext[index]
            index += 1

    plaintext = ''
    for row in matrix:
        plaintext += ''.join(row)

    return plaintext


# Example usage:
plaintext = "HELLO WORLD"
key = [3, 1, 2]
encrypted_text = column_transposition_encrypt(plaintext, key)
print("Encrypted:", encrypted_text)
decrypted_text = column_transposition_decrypt(encrypted_text, key)
print("Decrypted:", decrypted_text)

