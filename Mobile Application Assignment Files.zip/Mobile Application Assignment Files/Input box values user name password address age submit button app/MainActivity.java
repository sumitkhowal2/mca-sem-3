package com.example.inputboxvalues;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText editTextUserName, editTextPassword, editTextAddress, editTextAge;
    RadioGroup radioGroupGender;
    RadioButton radioButtonMale, radioButtonFemale;
    Button buttonSubmit;
    TextView textViewDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextUserName = findViewById(R.id.editTextUserName);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextAge = findViewById(R.id.editTextAge);

        radioGroupGender = findViewById(R.id.radioGroupGender);
        radioButtonMale = findViewById(R.id.radioButtonMale);
        radioButtonFemale = findViewById(R.id.radioButtonFemale);

        buttonSubmit = findViewById(R.id.buttonSubmit);
        textViewDetails = findViewById(R.id.textViewDetails);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = editTextUserName.getText().toString();
                String password = editTextPassword.getText().toString();
                String address = editTextAddress.getText().toString();
                int age = Integer.parseInt(editTextAge.getText().toString());

                String gender;
                int selectedId = radioGroupGender.getCheckedRadioButtonId();
                if(selectedId == R.id.radioButtonMale) {
                    gender = "Male";
                } else {
                    gender = "Female";
                }

                String userDetails = "User Name: " + userName +
                        "\nPassword: " + password +
                        "\nAddress: " + address +
                        "\nGender: " + gender +
                        "\nAge: " + age;

                textViewDetails.setText(userDetails);
            }
        });
    }
}
