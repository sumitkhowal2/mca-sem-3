package com.example.passvalues;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textView = findViewById(R.id.textView);

        // Get the intent that started this activity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            // Extract the text value from the intent extras
            String textValue = extras.getString("textValue");

            // Display the text value in TextView
            textView.setText(textValue);
        }
    }
}
