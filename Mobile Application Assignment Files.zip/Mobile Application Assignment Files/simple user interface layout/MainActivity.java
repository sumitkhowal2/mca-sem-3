package com.example.helloworld;




import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
public class MyActivity extends AppCompatActivity {
private LinearLayout layout1, layout2;
private Button switchButton;
}
@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.activity_main);
layout1 = findViewById(R.id.layout1);
layout2 = findViewById(R.id.layout2);
switchButton = findViewById(R.id.switch_button);
switchButton.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View v) {
toggleLayouts();
}
});
}
private void toggleLayouts() {
if (layout1.getVisibility() == View.VISIBLE) {
layout1.setVisibility(View.GONE);
layout2.setVisibility(View.VISIBLE);
} else {
layout2.setVisibility(View.GONE);
layout1.setVisibility(View.VISIBLE);
}
}
