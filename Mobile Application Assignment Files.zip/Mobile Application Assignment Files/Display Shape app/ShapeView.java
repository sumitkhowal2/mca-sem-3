package com.example.displayshapes;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class ShapeView extends View {

    private Paint paint;
    private Shape shape = Shape.RECTANGLE;

    public enum Shape {
        RECTANGLE,
        CIRCLE,
        TRIANGLE
    }

    public ShapeView(Context context) {
        super(context);
        init();
    }

    public ShapeView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ShapeView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.BLUE);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();

        switch (shape) {
            case RECTANGLE:
                // Draw a rectangle
                RectF rectF = new RectF(50, 50, width - 50, height - 50);
                canvas.drawRect(rectF, paint);
                break;
            case CIRCLE:
                // Draw a circle
                canvas.drawCircle(width / 2f, height / 2f, Math.min(width, height) / 4f, paint);
                break;
            case TRIANGLE:
                // Draw a triangle
                float halfWidth = width / 2f;
                float halfHeight = height / 2f;
                canvas.drawLine(halfWidth, 50, 50, height - 50, paint);
                canvas.drawLine(50, height - 50, width - 50, height - 50, paint);
                canvas.drawLine(width - 50, height - 50, halfWidth, 50, paint);
                break;
        }
    }

    public void setShape(Shape shape) {
        this.shape = shape;
        invalidate(); // Refresh the view to draw the new shape
    }
}
