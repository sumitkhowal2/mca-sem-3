package com.example.displayshapes;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private ShapeView shapeView;
    private Button rectangleButton;
    private Button circleButton;
    private Button triangleButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        shapeView = findViewById(R.id.shapeView);
        rectangleButton = findViewById(R.id.rectangleButton);
        circleButton = findViewById(R.id.circleButton);
        triangleButton = findViewById(R.id.triangleButton);

        rectangleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show rectangle shape
                shapeView.setShape(ShapeView.Shape.RECTANGLE);
            }
        });

        circleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show circle shape
                shapeView.setShape(ShapeView.Shape.CIRCLE);
            }
        });

        triangleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show triangle shape
                shapeView.setShape(ShapeView.Shape.TRIANGLE);
            }
        });
    }
}
